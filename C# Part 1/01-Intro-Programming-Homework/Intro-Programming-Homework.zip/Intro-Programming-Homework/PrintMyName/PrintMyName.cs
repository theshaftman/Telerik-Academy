﻿using System;

class PrintMyName
{
    static void Main()
    {
        string fullName = "Mariyan Vasilev";
        
        Console.WriteLine(fullName);
    }
}
