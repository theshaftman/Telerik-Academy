﻿using System;

class SquareRoot
{
    static void Main()
    {
        int number = 12345;
        double squareRoot = Math.Sqrt(number);
        //int squareRoot = Convert.ToInt32(Math.Sqrt(a));

        Console.WriteLine(squareRoot);
    }
}
