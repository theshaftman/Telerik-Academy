﻿using System;

class PrintFirstAndLastName
{
    static void Main()
    {
        string firstName = "Mariyan";
        string lastName = "Vasilev";

        Console.WriteLine("{0}\n{1}", firstName, lastName);
    }
}
