﻿using System;

class PrintNumbers
{
    static void Main()
    {
        // Write a program to print the numbers 1, 101 and 1001

        sbyte firstNum = 1;
        sbyte secondNum = 101;
        short thirdNum = 1001;

        Console.WriteLine("{0}\n{1}\n{2}", firstNum, secondNum, thirdNum);
    }
}
