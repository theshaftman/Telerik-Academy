﻿using System;

class HelloCSharp
{
    static void Main()
    {
        Console.WriteLine("Hello C#!");
    }
}
